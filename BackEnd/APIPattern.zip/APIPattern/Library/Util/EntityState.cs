﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Library
{
    public enum EntityState
    {
        None = 0,
        Insert = 1,
        Update = 2,
        Delete = 3
    }
}