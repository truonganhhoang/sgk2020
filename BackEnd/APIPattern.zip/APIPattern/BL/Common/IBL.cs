﻿

using BO;

namespace BL
{
    public interface IBL
    {
    }
}
