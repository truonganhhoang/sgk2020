﻿1. Xây dựng base
- làm các nào mà base có thể cất đối tượng theo BO?
- Cách để injection vào controller, BL thông qua base ?
- xử lý các hàm UnitOfWork ra sao ?
	+ Có transaction và command rồi => mapping parameters ra sao?
	+ Đặt các hàm beforsave, aftersave, before/afterDelete
	+ custom ServiceResult
- Đọc chuỗi query ra từ collection Json, sau đó replace chuỗi đó?